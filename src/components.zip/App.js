import logo from './logo.svg';
import './App.css';
import {BrowserRouter as Router , Route, useHistory ,Switch } from 'react-router-dom';
import Home from './components/Home'
function App() {
  return (
    <Router>
      <Route exact path='/'><Home/>      </Route>
    </Router>
  );
}

export default App;
