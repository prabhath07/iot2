import React from 'react';
import{Link } from 'react-router-dom';
import HomeIcon from '@material-ui/icons/Home';
import MeetingRoomIcon from '@material-ui/icons/MeetingRoom';
import EqualizerIcon from '@material-ui/icons/Equalizer';
function Navbar(){

    return(
        <div className='navbar'>
              <div className='profile'>
                 <span>
                     AUTOMATION
                 </span>

              </div>
              <div className='nav'>
                  <div className='home'>
                      < HomeIcon style={{ color: 'white' }} fontSize="large"></HomeIcon>
                      <Link to='/' style={{textDecoration:'none'}}><span className='navtit'>HOME</span></Link>
                  </div>
                  <div className='rooms' >
                      <MeetingRoomIcon style={{ color: 'white' }} fontSize="large">

                      </MeetingRoomIcon>
                  <Link to='/rooms' style={{textDecoration:'none'}}><span className='navtit'>ROOMS</span></Link>
                  </div>
                  <div className='stats'>
                      <EqualizerIcon style={{ color: 'white' }} fontSize="large"> 

                      </EqualizerIcon>
                  <Link to='/stats' style={{textDecoration:'none'}}><span className='navtit'>STATS</span></Link>
                  </div>

              </div>
        </div>
    )
}
export default Navbar;