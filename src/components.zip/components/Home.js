import React from 'react';
import Navbar from './Navbar'

function Home(){
    return(
    
        <div className='App'> 
         <Navbar/>

        </div>
        
        
        
        )

}

export default Home;